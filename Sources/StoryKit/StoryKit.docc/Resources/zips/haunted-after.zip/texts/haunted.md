=== node: gf_foyer_entry ===
A storm presses against the house on Ash Tree Lane. In the foyer, cold drafts slip through keyholes and lift the frayed fringes of the carpet. The door behind you has swollen in its frame.

=== node: gf_foyer_search ===
You lift a corner of the runner and find indentations that do not match the nail pattern beneath. Something heavy was dragged toward the east hall.

=== node: gf_east_hall_entry ===
The east hall pulls long in your eyes, as if each step adds a foot to its length. A faded runner is misaligned with the floorboards beneath, exposing dark seams.

=== node: gf_east_hall_search ===
The wallpaper is damp to the touch. When you peel it back, you see a second layer of older paper underneath, printed with spirals that lead the eye inward.

=== node: gf_west_hall_entry ===
The west hall lists slightly, as though the house has shifted on its foundation. A pulse—more felt than heard—beats through the wood under your shoes.

=== node: gf_west_hall_search ===
You crouch and press your ear to the floorboards. The pulse is not a machine; it is a living rhythm, too slow to be a heart.

=== node: gf_library_entry ===
Shelves sag under books swollen by damp. The air smells like paper and mold and a faint medicinal tang. One book juts crookedly from a row of histories.

=== node: gf_library_search ===
Your fingers stick to the lacquer as you pull volumes free. Between them glints a shard of a mirror, its back silvering eaten away in lace patterns that suggest a coastline on a void.

=== node: gf_parlor_entry ===
The parlor’s drapes hang like mourning veils. A phonograph waits on a small table, its brass horn turned toward the center of the room like an ear.

=== node: gf_parlor_search ===
You wind the crank and the cylinder spins. A woman’s voice unfurls backward at first, then clicks into place, whispering a request: “Do not answer the door after midnight.”

=== node: gf_dining_entry ===
The dining table is set for an even dozen, though the chairs do not match. One place bears a child’s cup painted with a lamb that has too many legs.

=== node: gf_dining_search ===
Under the silver cloche, you expect dust. Instead, you find a heap of common salt, damp and clumped, as though it has recently drawn moisture from the air.

=== node: gf_kitchen_entry ===
The kitchen tiles are spiderwebbed with fine cracks. The icebox hums faintly though its cord is cut, and the dumbwaiter’s door is marked by fingernail scratches.

=== node: gf_kitchen_search ===
Inside the icebox you find a wrapped bundle that proves to be a length of iron with a hand-crank welded to one end. It is clean despite the grime of everything else.

=== node: gf_pantry_entry ===
Rows of jars hold peaches bleached almost white, beets that have stained their brine, and something that might be eggs with shadows where yolks should be.

=== node: gf_pantry_search ===
You count the jars by touch. There are thirteen on the first shelf, twelve on the second, thirteen on the third—counting in the pantry never totals correctly the first time.

=== node: gf_study_entry ===
The study’s door doesn’t fit its frame; someone shaved it down until it closes with a whisper. The desk is neat in the way of someone who tidied a mess in haste.

=== node: gf_study_search ===
In the bottom drawer you find a note written in a boxy cipher that substitutes letters for little shapes: a circle for A, a square for E, a triangle that appears too often to be I.

=== node: gf_conservatory_entry ===
Glass panes are filmed with algae, muting the storm to a greenish blur. Vines have escaped their pots and rooted in the cracks between slate.

=== node: gf_conservatory_search ===
You brush aside a curtain of brittle leaves and uncover a bench scored with cuts. Someone tested blades here, from penknife to something that bit deep.

=== node: gf_ballroom_entry ===
A chandelier hangs with half its crystals missing, throwing ragged light across a parquet that rises and falls as if it had swelled and shrunk with the house’s breathing.

=== node: gf_ballroom_search ===
You cross to the mirrored wall and see yourself twice: once correctly and once delayed by half a blink. In the lag, your reflection smiles.

=== node: gf_gallery_entry ===
Portraits watch from within tarnished ovals. Several have been turned to face the wall. The ones that haven’t seem to lean imperceptibly toward the center of the corridor.

=== node: gf_gallery_search ===
Behind one portrait you find a recess the size of a cigar box and nothing in it but dust. On the dust lies a finger-width track, as if something crawled away.

=== node: stairs_main_uf ===
The main staircase curves like a rib cage. At its top, the air thins, humming with a frequency that tightens the scalp.

=== node: uf_landing_entry ===
The landing carries the smell of old soap and starch. Frames line the wall, their photographs faded to silhouettes with pale bursts where eyes once were.

=== node: uf_landing_search ===
You crouch and feel beneath the runner for loose boards. One gives, revealing a bundle of letters tied with kitchen twine, their ink bled into the paper like bruises.

=== node: uf_master_entry ===
The master bedroom is neatly made. The pillow dents have a second, shallower set within them, as if heads smaller than human had rested there.

=== node: uf_master_search ===
A tarnished locket holds a lock of hair that floats when you breathe on it. The photograph inside is not of a person but of a room that looks exactly like this one.

=== node: uf_bathroom_entry ===
The claw-foot tub is stained with mineral ghosts. The mirror, mottled with age, resists reflecting the whole of you at once.

=== node: uf_bathroom_search ===
You wipe a clear oval and see the door behind you swing shut in the glass. When you spin, the door remains open; only the mirror is honest.

=== node: uf_guest_east_entry ===
The east guest room is small and overfurnished, crowded with furniture that seems too eager to be useful. A bedspread crochets a pattern your eyes snag on.

=== node: uf_guest_east_search ===
Under the bed you find a child’s shoe with stones sewn into the lining. On the inside of the heel, a thumbprint of dried wax.

=== node: uf_guest_west_entry ===
The west guest room was once cheerful; the ghost of a yellow wallpaper remains in sun-protected diamonds behind where frames used to be.

=== node: uf_guest_west_search ===
Between the mattress and the frame is a page torn from a manual: an illustration of a hand placing a mirror shard against a chalk circle.

=== node: uf_nursery_entry ===
A mobile of paper birds turns slowly though the window is shut. There is no crib, only a low bed and the suggestion of a lullaby in the plumbing.

=== node: uf_nursery_search ===
The music box clicks open. The melody emerges in a minor key that seems to lower the floor by a fraction of an inch under your feet.

=== node: uf_sewing_entry ===
The sewing room smells of oil and iron. A treadle machine lurks beneath a shroud of muslin, its wheel smeared with a thumb of drying rust.

=== node: uf_sewing_search ===
In a notions tin you find needles magnetized into a tiny compass that spins when you hold your breath and stops when you exhale.

=== node: uf_storage_entry ===
Trunks pile like the baggage of people who meant to leave quickly and did not. Moth-blown coats slough to the floor if you touch them.

=== node: uf_storage_search ===
You pry up a trunk false bottom. Below is a chalk diagram: a loop crossed by lines, annotated in a cramped hand with angles that do not sum to sense.

=== node: uf_attic_entry ===
The attic is a country of dust dunes and furniture bones. In the corner lies a skin-bound tome that warms under your palm as if alive.

=== node: uf_attic_search ===
You sound the glyphs out under your breath. The room narrows, the eaves bowing inward with each syllable.

=== node: uf_attic_ritual ===
A draft spirals, pulling papers and twine into orbit around a point in the air where the light seems thicker. Shadows mass at the edge of the beam from your lantern.

=== node: dumbwaiter_gf ===
The dumbwaiter smells of old bread and iron. Its rope is smooth from a century of hands and something else that is not hands at all.

=== node: dumbwaiter_uf ===
You unfold yourself onto a service landing that exists between floors. Someone chalked a tally of days here, then scratched them out hard enough to gouge the plaster.

=== node: secret_library_passage ===
The shelf swings inward on silent hinges. A stair angles up at a pitch that seems designed for a different body plan.

=== node: secret_pantry_chute ===
You wriggle into the dark and slide in increments, the wood polished by generations of flour-dusted backs. The world smells of grain and stone.

=== node: bs_stairs_down_entry ===
Basement air rises to meet you: damp, mineral, spored with the patience of stone. Water ticks somewhere in the distance like an indifferent metronome.

=== node: bs_stairs_down_search ===
Along the riser someone carved a sequence of marks you recognize from the cipher note. Here the triangles add up to a warning.

=== node: bs_wine_entry ===
Bottle racks stand like ranks of vertebrae. One rack has been dragged aside to reveal an arch. The dust there is thin, recently disturbed.

=== node: bs_wine_search ===
You pull a bottle at random. The cork comes away dry and crumbly, and the wine inside is clearer than water, smelling faintly of camphor.

=== node: bs_boiler_entry ===
The boiler clicks as it contracts. Its pressure gauge trembles uselessly in the red. Pipes wander like veins into the walls.

=== node: bs_boiler_search ===
Under a layer of soot, someone has chalked a circle and crossed it with a careful line. Your breath smears the chalk and the circle seems relieved.

=== node: bs_storage_entry ===
Crates slump in the damp. Rotted labels suggest toffees, phonograph needles, and a brand of soap you’ve never heard of.

=== node: bs_storage_search ===
Behind stacked boards is an opening just wide enough for a shoulder. Stale air moves there, as if something on the other side has just exhaled.

=== node: bs_coal_room_entry ===
Coal dust coats everything, swallowing your footsteps with a muffled hush. Your fingertips come away black and greasy.

=== node: bs_coal_room_search ===
You brush aside cinders until your nails strike glass. A small pane, sooted opaque, clinks under your touch.

=== node: bs_root_cellar_entry ===
Rough shelves hold jars furred with slow mold, lids domed with pressure. The smell is sweet and wrong, like fruit that remembers meat.

=== node: bs_root_cellar_search ===
The far wall is cooler. Your palm sticks when you press it there, as if the stone were the inside of a mouth.

=== node: bs_cistern_entry ===
A round chamber collects water and whispers. A thin surface scum takes your ripples and translates them into words you cannot quite catch.

=== node: bs_cistern_search ===
Your reflection is delayed and not entirely yours. Something stands to your left in the water-world, just outside the circle of your lamp.

=== node: bs_tunnel_entry ===
The tunnel’s clay walls hold the memory of hands. Some of the finger-gouges run vertically, as if the tunnel were used as a well by things that never climbed.

=== node: bs_tunnel_search ===
When you tap, the sound returns at a pitch wrong for stone. There is a cavity on the other side lined in something that dampens.

=== node: bs_catacombs_entry ===
Chalk arrows mark paths through a lace of corridors. Each arrow points only until you pass it; afterward, it points somewhere else entirely.

=== node: bs_catacombs_search ===
A niche holds bones arranged by radius and tibia into a delicate lattice that would collapse if you breathed harder.

=== node: bs_ritual_entry ===
An octagonal chamber inscribed with circles layered over circles. The chalk holds the memory of many shoes and something like hooves.

=== node: encounter_shadow1 ===
The light in your lamp gutters without flame. The shadow across the far wall bulges until it becomes a depth: the width of a doorway where no doorway is.

=== node: encounter_shadow2 ===
The shadow licks the chalk like oil on water, skimming the surface until it finds an edge to pour itself through.

=== node: events_shard_mirror ===
The mirror shard weighs more than glass and less than a secret. When you hold it up, the room bends as if it preferred to be on the other side.

=== node: events_locket_memory ===
The locket’s photograph refreshes when you blink. For a second, you see a figure at the window, then only your own breath fogging the glass.

=== node: events_cipher_note ===
You map shapes to letters by instinct, not rule. The message is short: “The house is a mouth. Do not be a tongue.”

=== node: events_crank_winch ===
The iron crank nests into an invisible fitting with a satisfying click. When you turn it, something far away ratchets with a sound like teeth.

=== node: end_good ===
You press the mirror shard to the breach and the air seals with a sound like a kiss pulled through a keyhole. The house exhales you onto the porch into honest rain.

=== node: end_dead ===
The floor opens like a pupil and you fall into the eye, past angles that cannot exist in a world with a horizon. The last thing you hear is a page turning.

=== node: end_mad1 ===
Your thoughts dilute until you cannot tell them from the hiss of the cistern. You forget the shape of your mouth and the purpose of doors.

=== node: end_mad2 ===
You memorize the house’s heartbeat until yours matches it. When you step, the floor steps you.

=== node: end_mad3 ===
Language slips its leash. Nouns go first, then verbs; last is the word for you, and the relief is immediate.

=== node: end_bare1 ===
You stagger out with your skin intact but light will never sit correctly on your face again. Cameras shiver when pointed toward you.

=== node: end_bare2 ===
The shadow does not want your body, only your certainty. You keep walking because stopping requires reasons and you are fresh out.

=== node: end_bare3 ===
You seal the attic and keep the shard. At night you hold it to your chest to feel the house’s distant tide moving under your ribs.

