This is a placeholder for the Haunted Starter project. Replace with the real broken starter.
