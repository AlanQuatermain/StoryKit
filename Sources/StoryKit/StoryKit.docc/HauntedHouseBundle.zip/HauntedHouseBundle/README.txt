This is a placeholder for the Haunted House bundle. Replace with the real compiled bundle.
